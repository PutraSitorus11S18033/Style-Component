import React from "react";
import { StyledButton } from "./styles/Button";
export default function Button() {
  return <StyledButton> Buy </StyledButton>;
}
