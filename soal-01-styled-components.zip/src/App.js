import Card from "./components/Card";

export default function App() {
  return (
    <>
      <Card />
    </>
  );
}
